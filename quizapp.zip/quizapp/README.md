# Exam Prep Quiz App (Streamlit)

Topic-wise MCQ practice app for Bank PO/Clerk, IT placement, and DS/DA prep.

## Folder Structure
```
quizapp/
├── app.py
├── requirements.txt
├── README.md
└── data/
    ├── bank_quant.json
    ├── bank_reasoning.json
    ├── bank_verbal.json
    ├── bank_di.json
    ├── it_aptitude.json
    └── ds_da.json
```

## JSON format (har question is shape mein hona chahiye)
```json
{
  "id": "BQ001",
  "question": "Question text here",
  "options": ["Option A", "Option B", "Option C", "Option D"],
  "answer": "Option B",
  "explanation": "Short explanation"
}
```
Naye questions add karne ke liye bas usi topic ki JSON file mein array ke andar naya object add karo.

## Run Locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## GitHub Upload — Kya kya push karna hai
Repo mein yeh sab upload karo (poora folder as-is):
- `app.py`
- `requirements.txt`
- `data/` folder (saari JSON files ke saath)
- `README.md`

**Upload NAHI karna:**
- `__pycache__/` (agar bane)
- `.venv/` ya koi virtual environment folder
- OS junk files (`.DS_Store`)

### Git commands (naya repo se)
```bash
git init
git add .
git commit -m "Initial quiz app"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

## Streamlit Community Cloud par Deploy (free)
1. https://share.streamlit.io par jao, GitHub se login karo.
2. "New app" → apna GitHub repo select karo.
3. Branch: `main`, Main file path: `app.py`
4. "Deploy" click karo — 1-2 min mein live URL mil jayega.

Bas itna hi — koi API key ya secret is app mein chahiye nahi, seedha deploy ho jayega.

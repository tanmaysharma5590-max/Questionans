# Exam Prep — Aptitude Mock Test (v2, single-file format)

This is a NEW, more advanced version of the app — timer, negative marking,
question palette, section-wise filtering. It uses a different file structure
than the earlier version.

## Structure (IMPORTANT — must match exactly in your GitHub repo)
```
your-repo/
├── app.py              ← replace your old app-1.py with this
├── requirements.txt
└── questions.json       ← single file, all 199 questions
```

**No `data/` folder in this version** — everything is in one `questions.json`
file that must sit in the SAME directory as `app.py`.

## Why you were getting "Could not find quantitative_aptitude.json"

That error was from the OLD app (`app-1.py`), which looked for six separate
files inside a `data/` folder. This NEW app (`app.py`) doesn't use that
structure at all — it loads everything from a single `questions.json`.

To fix it for good:
1. Delete (or ignore) the old `app-1.py` and the `data/` folder in your repo
   — or make sure Streamlit Cloud's "Main file path" points to the new `app.py`.
2. Upload these 3 files to your repo root: `app.py`, `requirements.txt`, `questions.json`.
3. On Streamlit Cloud: **Manage app → Settings → Main file path** → set to `app.py`.
4. **Manage app → Reboot app**.

## Question format (questions.json)
```json
{
  "id": 1,
  "section": "Quantitative Aptitude",
  "subsection": "",
  "question": "Question text here",
  "options": ["Option A", "Option B", "Option C", "Option D"],
  "correct_index": 0,
  "explanation": "Full step-by-step explanation."
}
```
`correct_index` is the 0-based position of the correct answer in `options`
(0 = first option, 1 = second, etc.) — not the answer text itself.

## Adding more questions
Append new objects to the `questions.json` array with a unique, incrementing
`id`. No code changes needed — the app reads whatever sections exist in the file
and builds the section filter automatically.

## Current bank: 199 questions across 12 sections
Quantitative Aptitude (19), Logical Reasoning (18), Verbal Ability (8),
Data Interpretation (8), Data Analysis & Data Science (9), Banking Awareness (8),
Statistics (64), Python & Libraries (15), SQL (15), Machine Learning (15),
Deep Learning (10), GenAI & Agentic AI (10).

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```
